import sys
sys.path.append(".")

import unittest
import fileinput
import project5_US4
class TestGedcom(unittest.TestCase):
    def test_lastname(self):
        for i in project5_US4.singles:
            self.assertGreater(int(project5_US4.age[i]),30,"they are not single")
if __name__ == '__main__':
    unittest.main()



