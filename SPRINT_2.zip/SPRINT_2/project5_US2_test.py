import sys
sys.path.append(".")

import unittest
import fileinput
import project5_US2
class TestGedcom(unittest.TestCase):
    def test_lastname(self):
        for i in project5_US2.male:
            name=i.split()
            length=len(name)
            self.assertEqual(name[length-1],project5_US2.familyname)
if __name__ == '__main__':
    unittest.main()

