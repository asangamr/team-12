import sys
sys.path.append(".")

import unittest
import fileinput
import project5_US3
class TestGedcom(unittest.TestCase):
    def test_lastname(self):
        for i in str(project5_US3.id_wife):
            age_wife=project5_US3.age[project5_US3.id_wife]
            age_husband=project5_US3.age[project5_US3.id_husband]
            self.assertGreater(age_husband,2*age_wife,"there is large age difference")
if __name__ == '__main__':
    unittest.main()


