import sys
sys.path.append(".")

import unittest
import fileinput
import project5_US1
class TestGedcom(unittest.TestCase):
    def test_age(self):
        self.assertGreater(int(project5_US1.age[project5_US1.id_wife]),14,"wife age is not greater than 14")
        self.assertGreater(int(project5_US1.age[project5_US1.id_husband]),14,"husband age is not greater than 14")
if __name__ == '__main__':
    unittest.main()
