import sys
sys.path.append(".")

import unittest
import fileinput
import Sprint3_US2
count=0
succ=1
pre=0
sibling_test=[]
class TestGedcom(unittest.TestCase):
    def test_sibling(self):
        count=0
        succ=1
        pre=0
        while(count<len(Sprint3_US2.identity)):
            Sibling_name=Sprint3_US2.name[count]
            DOB1=Sprint3_US2.birthday[count]
            Sibling1_fam=Sprint3_US2.child[count]
            DOB1=DOB1.replace("-"," ")
            DOB1_split=DOB1.split()
            #print(Sibling_name)
            while(succ<len(Sprint3_US2.identity)-1):
                Sibling_name2=Sprint3_US2.name[succ]
                DOB2=Sprint3_US2.birthday[succ]
                Sibling2_fam=Sprint3_US2.child[succ]
                DOB2=DOB2.replace("-"," ")
                DOB2_split=DOB2.split()
                #print(Sibling_name2)
                if(Sibling1_fam=="NA" and Sibling2_fam=="NA"):
                    break
                elif(Sibling1_fam==Sibling2_fam):
                    if(DOB1_split[0]==DOB2_split[0]):
                        if(DOB1_split[1]==DOB2_split[1]) and abs(int(DOB1_split[2])-int(DOB2_split[2]))<=2:
                            print("")
                        elif(DOB1_split[1]==DOB2_split[1]) and abs(int(DOB1_split[2])-int(DOB2_split[2]))>2:
                            sibling_test.append(Sibling_name)
                        elif abs(int(DOB1_split[1])-int(DOB2_split[1]))>8:
                            print("")
                        elif abs(int(DOB1_split[1])-int(DOB2_split[1]))<8:
                            sibling_test.append(Sibling_name)
                            
                    elif(DOB1_split[0]!=DOB2_split[0]):
                        if abs(int(DOB1_split[0])-int(DOB2_split[0]))==1:
                            if int(DOB1_split[0])>int(DOB2_split[0]):
                                month1=12-int(DOB1_split[1])
                                month2=int(DOB2_split[1])
                                month=month1+month2
                                if(month>8):
                                    print("")
                                else:
                                    sibling_test.append(Sibling_name)
                                    
                            else:
                                sibling_test.append(Sibling_name)
                                
                        else:
                            print("")
                            
                            
                succ=succ+1
            pre=pre+1
            succ=pre
            count=count+1

        self.assertEqual(sibling_test,Sprint3_US2.sibling)
if __name__ == '__main__':
    unittest.main()
    

