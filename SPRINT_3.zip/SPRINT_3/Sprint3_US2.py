import fileinput
import datetime
from prettytable import PrettyTable
        
def date_func(m):
    if m[3]=="JAN":
        month=1
    elif m[3]=="FEB":
        month=2
    elif m[3]=="MAR":
        month=3
    elif m[3]=="APR":
        month=4
    elif m[3]=="MAY":
        month=5
    elif m[3]=="JUN":
        month=6
    elif m[3]=="JUL":
        month=7
    elif m[3]=="AUG":
        month=8
    elif m[3]=="SEP":
        month=9
    elif m[3]=="OCT":
        month=10
    elif m[3]=="NOV":
        month=11
    else:
        month=12
    d1 = datetime.date(int(m[4]),month,int(m[2]))
    return d1
    
    
lIne=[]
age=0
i=0
identity=[]
name=[]
gender=[]
birthday=[]
age=[]
alive=[]
death=[]
child=[]
spouse=[]
cond1="BIRT"
cond2="DEAT"
cond3="FAMS"
cond4="MARR"
l="NA"
identity1=[]
married=[]
divorced=[]
husband_id=[]
husband_name=[]
wife_id=[]
wife_name=[]
children=[]
sibling=[]
columns = ["Identity", "Name", "Gender", "Birthday","Age","Alive","Death","Child","Spouse"]
from datetime import date
d2 = date.today()

  
# Using fileinput.input() method

for line in fileinput.input(files ='/Users/kiranmaigudiyella/Downloads/My-Family.txt'):
    lIne.append(line)
x=len(lIne) 
#print(x)
while(x>0):
    j=lIne[i]
    m=j.split(" ",2)
    y=len(m)
    #while(y>0):
    if(m[1].startswith('@I')):
        identity.append(m[1])
            #print(identity)
    elif m[1]=="NAME" and m[0]=="1":
        name.append(m[2])
    elif m[1]=="SEX":
        gender.append(m[2])
            #print(name)
        #y=y-1
    
    if cond1 in j:
        y=lIne[i+1]
        m=y.split()
        d1=date_func(m)
        b=str(d1)
        birthday.append(b)
        if(d1<d2):
            age.append(str(d2.year - d1.year))
    
    if cond1 in j:
        q=lIne[i+2]
        if cond2 in q:
            y=lIne[i+3]
            m=y.split()
            d1=date_func(m)
            b=str(d1)
            death.append(b)
            child.append(l)
            spouse.append(l)
        else:
            death.append(l)
            child.append(l)
            spouse.append(l)
    if m[1]=="CHIL":
        p=m[2].replace("@","")
        pnew=p.lstrip("I")
        p1=int(pnew)
        z=i
        y=lIne[z]
        m1=y.split()
        while(not m1[2]=="FAM"):
            z=z-1
            y=lIne[z]
            m1=y.split()
        """if "FAM" in y:
            p1=p1-1
            child[p1]= m1[1]"""
        p1=p1-1
        child[p1]= m1[1]
    if m[1]=="HUSB" or m[1]=="WIFE":
        p=m[2].replace("@","")
        pnew=p.lstrip("I")
        p1=int(pnew)
        z=i
        y=lIne[z]
        m1=y.split()
        while(not m1[2]=="FAM"):
            z=z-1
            y=lIne[z]
            m1=y.split()
        #-------------------------------------------------------BAD SMELL:2 (If statement in the below commented block was not necessary)---------------------------
        """if "FAM" in y:
            p1=p1-1
            spouse[p1]= m1[1]"""
        p1=p1-1
        spouse[p1]= m1[1]
#----------------------------------------FAMILY TABLE---------------------------------------------#
    if(m[1].startswith('@F')):
        identity1.append(m[1])
        married.append(l)
        divorced.append(l)
        z=i+1
        y=lIne[z]
        m=y.split()
        while(not m[1].startswith('@F')):
            if cond4 in y:
                y=lIne[z+1]
                m=y.split()
                d1=date_func(m)
                b=str(d1)
                v=len(married)-1
                married[v]=b
            elif m[1]=="DIV":
                y=lIne[z+1]
                m=y.split()
                d1=date_func(m)
                b=str(d1)
                v=len(married)-1
                divorced[v]=b
            elif(m[1]=="HUSB"):
                p=m[2].replace("@","")
                husband_id.append(p)
                p=p.replace("I","")
                p=int(p)
                #print(type(p))
                husband_name.append(name[p-1])
                #husband_id.append(m[2])
            elif(m[1]=="WIFE"):
                p=m[2].replace("@","")
                wife_id.append(p)
                p=p.replace("I","")
                p=int(p)
                wife_name.append(name[p-1])
            
            if(m[1]=="TRLR"):
                break
                
            z=z+1
            y=lIne[z]
            m=y.split()
               
    x=x-1
    i=i+1
print("--------------------------INDIVIDUAL TABLE--------------------------------")
columns = ["Identity", "Name", "Gender", "Birthday","Age","Death","Child","Spouse"]
individuals = PrettyTable()
len_column=len(columns)
individuals.add_column(columns[0],identity)
individuals.add_column(columns[1],name)
individuals.add_column(columns[2],gender)
individuals.add_column(columns[3],birthday)
individuals.add_column(columns[4],age)
individuals.add_column(columns[5],death)
individuals.add_column(columns[6],child)
individuals.add_column(columns[7],spouse)
print(individuals)
print("--------------------------FAMILY TABLE--------------------------------")
columns_1=["ID","Married","Divorced","Husband_id","Husband_name","Wife_id","Wife_name"]
family=PrettyTable()
family.add_column(columns_1[0],identity1)
family.add_column(columns_1[1],married)
family.add_column(columns_1[2],divorced)
family.add_column(columns_1[3],husband_id)
family.add_column(columns_1[4],husband_name)
family.add_column(columns_1[5],wife_id)
family.add_column(columns_1[6],wife_name)

print(family)

#i1,i13,i2,i6,i10,i14,i15,i8,i9
count=0
gender_1=gender[count]
family=[]
for i in identity:
    if spouse[count]!="NA" and gender[count]==gender_1:
        age_wife=int(age[count])
        wife_name1=name[count]
        wife_name1=wife_name1.replace("\n","")
        spouse_id=spouse[count]
        '''if spouse_id in family:
            break'''
        family.append(spouse_id)
        ref=spouse_id
        print("--------------------"+spouse_id+"--------------------")
        #print("husband age"+str(age_husband))
        inx= identity1.index(spouse_id)
        spouse_id=husband_id[inx]
        spouse_id=spouse_id.replace("I","")
        inx=int(spouse_id)-1
        age_husband=int(age[inx])
        husband_name1=name[inx]
        husband_name1=husband_name1.replace("\n","")
        #print("wife age="+str(age_wife))
        if(age_husband>14 and age_wife>14 and (ref in family)):
            print("** COUPLE "+str(husband_name1)+"and "+wife_name1+":  **\n"+"->age is above 14")
        elif(age_husband<14 and (spouse_id in family)):
            print("** COUPLE "+str(husband_name1)+"age is below 14")
        elif(spouse_id in family):
            print("** COUPLE "+str(wife_name1)+"age is below 14")
        else:
            print("")
        if(age_husband>(2*age_wife)):
            print("*****COUPLE "+str(husband_name1)+"and "+wife_name1+":    there is large age difference")
        elif(age_wife>(2*age_husband)):
            print("*****COUPLE "+str(husband_name1)+"and "+wife_name1+":    there is large age difference")
        else:
            print("->there is NO large age difference")
    count=count+1
count=0
lastname=name[count].split()
familyname=lastname[2]
#print(familyname)
print("***************** MALE LAST NAME CHECK ******************")
for i in name:
    if(gender[count]!=gender_1):
        male=name[count]
        male=male.replace("\n","")
        ref=male.split()
        print("-----------------------------------------------------------------------------------------------")
        if(familyname in male):
            print("last name of "+male+" is same as the family name which is "+familyname)
        else:
            print("last name of "+male+" is NOT same as the family name which is "+familyname)
    count=count+1
print("*********************************************************")
count=0
print("***************** LIVING SINGLE ******************")
for i in name:
    if(int(age[count])> 30 and spouse[count]=="NA"):
        print(name[count]+"age is "+age[count]+" and STILL LIVING SINGLE")
    count=count+1
print("*********************************************************")
count=0
succ=1
pre=succ
print("***************************Siblings Spacing**************************")
while(count<len(identity)):
    Sibling_name=name[count]
    DOB1=birthday[count]
    Sibling1_fam=child[count]
    DOB1=DOB1.replace("-"," ")
    DOB1_split=DOB1.split()
    #print(Sibling_name)
    while(succ<len(identity)-1):
        Sibling_name2=name[succ]
        DOB2=birthday[succ]
        Sibling2_fam=child[succ]
        DOB2=DOB2.replace("-"," ")
        DOB2_split=DOB2.split()
        #print(Sibling_name2)
        if(Sibling1_fam=="NA" and Sibling2_fam=="NA"):
            break
        elif(Sibling1_fam==Sibling2_fam):
            if(DOB1_split[0]==DOB2_split[0]):
                if(DOB1_split[1]==DOB2_split[1]) and abs(int(DOB1_split[2])-int(DOB2_split[2]))<=2:
                    print(Sibling_name+" "+Sibling_name2+" is having valid age difference")
                elif(DOB1_split[1]==DOB2_split[1]) and abs(int(DOB1_split[2])-int(DOB2_split[2]))>2:
                    sibling.append(Sibling_name)
                    print(Sibling_name+" "+Sibling_name2+" is not having valid age difference")
                elif abs(int(DOB1_split[1])-int(DOB2_split[1]))>8:
                    print(Sibling_name+" "+Sibling_name2+" is having valid age difference")
                elif abs(int(DOB1_split[1])-int(DOB2_split[1]))<8:
                    sibling.append(Sibling_name)
                    print(Sibling_name+" "+Sibling_name2+" is not having valid age difference")
            elif(DOB1_split[0]!=DOB2_split[0]):
                if abs(int(DOB1_split[0])-int(DOB2_split[0]))==1:
                    if int(DOB1_split[0])>int(DOB2_split[0]):
                        month1=12-int(DOB1_split[1])
                        month2=int(DOB2_split[1])
                        month=month1+month2
                        if(month>8):
                            print(Sibling_name+" "+Sibling_name2+" is having valid age difference")
                        else:
                            sibling.append(Sibling_name)
                            print(Sibling_name+" "+Sibling_name2+" is not having valid age difference")
                    else:
                        sibling.append(Sibling_name)
                        print(Sibling_name+" "+Sibling_name2+" is not having valid age difference")
                else:
                    print(Sibling_name+" "+Sibling_name2+" is having valid age difference")
                    
                    
        succ=succ+1
    pre=pre+1
    succ=pre
    count=count+1
print("*********************************************************")
count=0
succ=1
pre=succ
    