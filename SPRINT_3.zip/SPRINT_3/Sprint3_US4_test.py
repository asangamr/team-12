import sys
sys.path.append(".")

import unittest
import fileinput
import Sprint3_US4
sibling_test=[]
class TestGedcom(unittest.TestCase):
    def test_sibling(self):
        count=0
        succ=1
        pre=0
        while(count<len(Sprint3_US4.identity)):
            Sibling_name=Sprint3_US4.name[count]
            Sibling1_fam=Sprint3_US4.child[count]
            Sibling1_spouse=Sprint3_US4.spouse[count]
            if(Sibling1_spouse==Sibling1_fam):
                sibling_test.append(Sibling_name)
                
            else:
                print("")
            count=count+1 
        self.assertEqual(sibling_test,Sprint3_US4.sibling)
if __name__ == '__main__':
    unittest.main()
    



