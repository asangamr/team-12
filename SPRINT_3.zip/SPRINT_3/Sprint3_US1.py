import fileinput
import datetime
from prettytable import PrettyTable
def date_func(m):
    if m[3]=="JAN":
        month=1
    elif m[3]=="FEB":
        month=2
    elif m[3]=="MAR":
        month=3
    elif m[3]=="APR":
        month=4
    elif m[3]=="MAY":
        month=5
    elif m[3]=="JUN":
        month=6
    elif m[3]=="JUL":
        month=7
    elif m[3]=="AUG":
        month=8
    elif m[3]=="SEP":
        month=9
    elif m[3]=="OCT":
        month=10
    elif m[3]=="NOV":
        month=11
    else:
        month=12
    d1 = datetime.date(int(m[4]),month,int(m[2]))
    return d1
    
    
lIne=[]
age=0
i=0
identity=[]
name=[]
gender=[]
birthday=[]
age=[]
alive=[]
death=[]
child=[]
spouse=[]
cond1="BIRT"
cond2="DEAT"
cond3="FAMS"
cond4="MARR"
l="NA"
identity1=[]
married=[]
divorced=[]
husband_id=[]
husband_name=[]
wife_id=[]
wife_name=[]
children=[]
bigamy=[]
columns = ["Identity", "Name", "Gender", "Birthday","Age","Alive","Death","Child","Spouse"]
from datetime import date
d2 = date.today()

  
# Using fileinput.input() method

for line in fileinput.input(files ='/Users/kiranmaigudiyella/Downloads/My-Family.txt'):
    lIne.append(line)
x=len(lIne) 
#print(x)
while(x>0):
    j=lIne[i]
    m=j.split(" ",2)
    y=len(m)
    #while(y>0):
    if(m[1].startswith('@I')):
        identity.append(m[1])
            #print(identity)
    elif m[1]=="NAME" and m[0]=="1":
        name.append(m[2])
    elif m[1]=="SEX":
        gender.append(m[2])
            #print(name)
        #y=y-1
    
    if cond1 in j:
        y=lIne[i+1]
        m=y.split()
        d1=date_func(m)
        b=str(d1)
        birthday.append(b)
        if(d1<d2):
            age.append(str(d2.year - d1.year))
    
    if cond1 in j:
        q=lIne[i+2]
        if cond2 in q:
            y=lIne[i+3]
            m=y.split()
            d1=date_func(m)
            b=str(d1)
            death.append(b)
            child.append(l)
            spouse.append(l)
        else:
            death.append(l)
            child.append(l)
            spouse.append(l)
    if m[1]=="CHIL":
        p=m[2].replace("@","")
        pnew=p.lstrip("I")
        p1=int(pnew)
        z=i
        y=lIne[z]
        m1=y.split()
        while(not m1[2]=="FAM"):
            z=z-1
            y=lIne[z]
            m1=y.split()
        """if "FAM" in y:
            p1=p1-1
            child[p1]= m1[1]"""
        p1=p1-1
        child[p1]= m1[1]
    if m[1]=="HUSB" or m[1]=="WIFE":
        p=m[2].replace("@","")
        pnew=p.lstrip("I")
        p1=int(pnew)
        z=i
        y=lIne[z]
        m1=y.split()
        while(not m1[2]=="FAM"):
            z=z-1
            y=lIne[z]
            m1=y.split()
        #-------------------------------------------------------BAD SMELL:2 (If statement in the below commented block was not necessary)---------------------------
        """if "FAM" in y:
            p1=p1-1
            spouse[p1]= m1[1]"""
        p1=p1-1
        spouse[p1]= m1[1]
#----------------------------------------FAMILY TABLE---------------------------------------------#
    if(m[1].startswith('@F')):
        print(m[1])
        identity1.append(m[1])
        married.append(l)
        divorced.append(l)
        z=i+1
        y=lIne[z]
        m=y.split()
        while(not m[1].startswith('@F')):
            if cond4 in y:
                y=lIne[z+1]
                m=y.split()
                d1=date_func(m)
                b=str(d1)
                v=len(married)-1
                print("V="+str(v))
                married[v]=b
            elif m[1]=="DIV":
                y=lIne[z+1]
                m=y.split()
                d1=date_func(m)
                b=str(d1)
                v=len(married)-1
                divorced[v]=b
            elif(m[1]=="HUSB"):
                p=m[2].replace("@","")
                husband_id.append(p)
                p=p.replace("I","")
                p=int(p)
                #print(type(p))
                husband_name.append(name[p-1])
                #husband_id.append(m[2])
            elif(m[1]=="WIFE"):
                p=m[2].replace("@","")
                wife_id.append(p)
                p=p.replace("I","")
                p=int(p)
                wife_name.append(name[p-1])
            
            if(m[1]=="TRLR"):
                break
                
            z=z+1
            y=lIne[z]
            m=y.split()
               
    x=x-1
    i=i+1
print("name"+husband_name[2])
print("--------------------------INDIVIDUAL TABLE--------------------------------")
columns = ["Identity", "Name", "Gender", "Birthday","Age","Death","Child","Spouse"]
individuals = PrettyTable()
len_column=len(columns)
individuals.add_column(columns[0],identity)
individuals.add_column(columns[1],name)
individuals.add_column(columns[2],gender)
individuals.add_column(columns[3],birthday)
individuals.add_column(columns[4],age)
individuals.add_column(columns[5],death)
individuals.add_column(columns[6],child)
individuals.add_column(columns[7],spouse)
print(individuals)
print("--------------------------FAMILY TABLE--------------------------------")
columns_1=["ID","Married","Divorced","Husband_id","Husband_name","Wife_id","Wife_name"]
family=PrettyTable()
family.add_column(columns_1[0],identity1)
family.add_column(columns_1[1],married)
family.add_column(columns_1[2],divorced)
family.add_column(columns_1[3],husband_id)
family.add_column(columns_1[4],husband_name)
family.add_column(columns_1[5],wife_id)
family.add_column(columns_1[6],wife_name)

print(family)

#i1,i13,i2,i6,i10,i14,i15,i8,i9
count=0
gender_1=gender[count]
family=[]
for i in identity:
    if spouse[count]!="NA" and gender[count]==gender_1:
        age_wife=int(age[count])
        wife_name1=name[count]
        wife_name1=wife_name1.replace("\n","")
        spouse_id=spouse[count]
        '''if spouse_id in family:
            break'''
        family.append(spouse_id)
        ref=spouse_id
        print("--------------------"+spouse_id+"--------------------")
        #print("husband age"+str(age_husband))
        inx= identity1.index(spouse_id)
        spouse_id=husband_id[inx]
        spouse_id=spouse_id.replace("I","")
        inx=int(spouse_id)-1
        age_husband=int(age[inx])
        husband_name1=name[inx]
        husband_name1=husband_name1.replace("\n","")
        #print("wife age="+str(age_wife))
        if(age_husband>14 and age_wife>14 and (ref in family)):
            print("** COUPLE "+str(husband_name1)+"and "+wife_name1+":  **\n"+"->age is above 14")
        elif(age_husband<14 and (spouse_id in family)):
            print("** COUPLE "+str(husband_name1)+"age is below 14")
        elif(spouse_id in family):
            print("** COUPLE "+str(wife_name1)+"age is below 14")
        else:
            print("")
        if(age_husband>(2*age_wife)):
            print("*****COUPLE "+str(husband_name1)+"and "+wife_name1+":    there is large age difference")
        elif(age_wife>(2*age_husband)):
            print("*****COUPLE "+str(husband_name1)+"and "+wife_name1+":    there is large age difference")
        else:
            print("->there is NO large age difference")
    count=count+1
count=0
lastname=name[count].split()
familyname=lastname[2]
#print(familyname)
print("***************** MALE LAST NAME CHECK ******************")
for i in name:
    if(gender[count]!=gender_1):
        male=name[count]
        male=male.replace("\n","")
        ref=male.split()
        print("-----------------------------------------------------------------------------------------------")
        if(familyname in male):
            print("last name of "+male+" is same as the family name which is "+familyname)
        else:
            print("last name of "+male+" is NOT same as the family name which is "+familyname)
    count=count+1
print("*********************************************************")
count=0
print("***************** LIVING SINGLE ******************")
for i in name:
    if(int(age[count])> 30 and spouse[count]=="NA"):
        print(name[count]+"age is "+age[count]+" and STILL LIVING SINGLE")
    count=count+1
print("*********************************************************")
count=0
succ=1
H_name=""
print("***************************** NO BIGAMY ****************************")
while(count<len(identity1)):
    H_name=husband_name[count]
    H_marr=married[count]
    while(succ<len(identity1)-1):
        H_name2=husband_name[succ]
        H_marr2=married[succ]
        if(H_name==H_name2):
            if(H_marr2==H_marr):
                bigamy.append(H_name)
                print("Bigamy is present with "+H_name)
        succ=succ+1
    count=count+1
count=0
succ=1
while(count<len(identity1)):
    W_name=wife_name[count]
    W_marr=married[count]
    while(succ<len(identity1)-1):
        W_name2=wife_name[succ]
        W_marr2=married[succ]
        if(W_name==W_name2):
            if(W_marr2==W_marr):
                print("Bigamy is present with "+W_name)
        succ=succ+1
    count=count+1
print("*********************************************************")            
count=0
succ=1
print(bigamy)
