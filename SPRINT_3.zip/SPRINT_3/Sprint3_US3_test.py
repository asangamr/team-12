import sys
sys.path.append(".")

import unittest
import fileinput
import Sprint3_US3
sibling_test=[]
class TestGedcom(unittest.TestCase):
    def test_sibling(self):
        count=0
        succ=1
        pre=0
        while(count<len(Sprint3_US3.identity)):
            Sibling_name=Sprint3_US3.name[count]
            Sibling1_fam=Sprint3_US3.child[count]
            sibling_count=0
            while(succ<len(Sprint3_US3.identity)-1):
                Sibling_name2=Sprint3_US3.name[succ]
                Sibling2_fam=Sprint3_US3.child[succ]
                if(Sibling1_fam==Sibling2_fam):
                    sibling_count=sibling_count+1
                succ=succ+1
            if(sibling_count>=5):
                sibling_test.append(Sibling_name)
            else:
                print("")
                
            count=count+1 
        self.assertEqual(sibling_test,Sprint3_US3.sibling)
if __name__ == '__main__':
    unittest.main()
    


