import sys
sys.path.append(".")

import unittest
import fileinput
import Sprint3_US1
bigamy_test=[]
class TestGedcom(unittest.TestCase):
    def test_Bigamy(self):
        count=0
        succ=1
        while(count<len(Sprint3_US1.identity1)):
            H_name1=Sprint3_US1.husband_name[count]
            H_marr=Sprint3_US1.married[count]
            while(succ<len(Sprint3_US1.identity1)-1):
                H_name2=Sprint3_US1.husband_name[succ]
                H_marr2=Sprint3_US1.married[succ]
                if(H_name1==H_name2):
                    if(H_marr2==H_marr):
                        bigamy_test.append(H_name1)
                succ=succ+1
            count=count+1
        self.assertEqual(bigamy_test,Sprint3_US1.bigamy)
if __name__ == '__main__':
    unittest.main()
    
